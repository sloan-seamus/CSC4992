#!/usr/bin/env python3

print("\n\nQuestion Two\n\n")
num1 = input("Enter a binary number: ")

print("You entered: {}\nIn decimal: {}\n\n".format(num1, int(num1, 2)))

"""
Test Cases:
    Enter a valid binary number
    Verify the binary number has been accurately converted to decimal
"""
